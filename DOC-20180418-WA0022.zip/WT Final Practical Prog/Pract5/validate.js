function validate()
{ 
   if( document.StudentRegistration.First_Name.value == "" )
   {
     alert( "Please provide your First Name!" );
     document.StudentRegistration.First_Name.focus() ;
     return false;
   }
   if( document.StudentRegistration.Last_Name.value == "" )
   {
     alert( "Please provide your Last_Name!" );
     document.StudentRegistration.Last_Name.focus() ;
     return false;
   }
   if( document.StudentRegistration.bday.value == "" )
   {
     alert( "Please provide your Birthdate!" );
     document.StudentRegistration.bday.focus() ;
     return false;
   }

   if( document.StudentRegistration.Email_Id.value == "" )
   {
     alert( "Please provide your Email_Id!" );
     document.StudentRegistration.Email_Id.focus() ;
     return false;
   }

   var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
   if (!/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/g.test(document.StudentRegistration.Email_Id.value)) {
    alert("Please provide correct Email Id !");
    document.StudentRegistration.Email_Id.focus();
    return false;
    }

    if( document.StudentRegistration.Email_Id.value == "" )
    {
      alert( "Please provide your Email_Id!" );
      document.StudentRegistration.Email_Id.focus() ;
      return false;
    }

    if( document.StudentRegistration.Mobile_Number.value == "" ||
    isNaN( document.StudentRegistration.Mobile_Number.value) ||
    document.StudentRegistration.Mobile_Number.value.length != 10 )
{
alert( "Please provide a Mobile No in the format 123." );
document.StudentRegistration.Mobile_Number.focus() ;
return false;
}

   if ( ( StudentRegistration.sex[0].checked == false ) && ( StudentRegistration.sex[1].checked == false ) )
   {
   alert ( "Please choose your Gender: Male or Female" );
   return false;
   }   

   if( document.StudentRegistration.Address.value == "" )
   {
     alert( "Please provide your Address!" );
     document.StudentRegistration.Address.focus() ;
     return false;
   }  

   if( document.StudentRegistration.City.value == "" )
   {
     alert( "Please provide your City!" );
     document.StudentRegistration.City.focus() ;
     return false;
   }   

   if( document.StudentRegistration.Pin_Code.value == "" )
   {
     alert( "Please provide your Pin Code!" );
     document.StudentRegistration.Pin_Code.focus() ;
     return false;
   }  

   if( document.StudentRegistration.State.value == "" )
   {
     alert( "Please provide your State!" );
     document.StudentRegistration.State.focus() ;
     return false;
   }  

   if( document.StudentRegistration.Country.value == "" )
   {
     alert( "Please provide your Country!" );
     document.StudentRegistration.Country.focus() ;
     return false;
   }  

   if( document.StudentRegistration.Hobbies.value == "" )
   {
     alert( "Please provide your Hobbies!" );
     document.StudentRegistration.Hobbies.focus() ;
     return false;
   }  

   if(( StudentRegistration.ClassX_Board.value == "") || ( StudentRegistration.ClassX_Percentage.value == "") || ( StudentRegistration.ClassX_YrOfPassing.value == "")  )
   {   
     alert( "Please provide your 10th deatails!" );
     document.StudentRegistration.Hobbies.focus() ;
     return false;
   }  

   if(( StudentRegistration.ClassXII_Board.value == "") || ( StudentRegistration.ClassXII_Percentage.value == "") || ( StudentRegistration.ClassXII_YrOfPassing.value == "") )
   {
     alert( "Please provide your 12th/Diploma deatails!" );
     document.StudentRegistration.Hobbies.focus() ;
     return false;
   }  

   if ( ( StudentRegistration.BE[0].checked == false ) && ( StudentRegistration.BE[1].checked == false ))
   {
   alert ( "Please choose your Course: BE or ME" );
   return false;
   }  

   return( true );
}